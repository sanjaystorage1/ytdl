alter table settings
    add mode varchar(32) default 'Celery' null;

